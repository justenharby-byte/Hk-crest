using BepInEx;
using BepInEx.Logging;
using Needleforge;
using Needleforge.Data;
using TeamCherry.Localization;
using UnityEngine;
using static AlphaOmegaCrest.Utils.ResourceUtils;

namespace AlphaOmegaCrest;

[BepInAutoPlugin(id: "io.github.alphaomegacrest")]
[BepInDependency("org.silksong-modding.i18n", "1.1.1")]
[BepInDependency("io.github.needleforge", "0.9.0")]
public partial class AlphaOmegaCrestPlugin : BaseUnityPlugin {

    internal static ManualLogSource Log { get; private set; } = null!;
    internal static CrestData Crest { get; private set; } = null!;

    internal const string CrestId = "AlphaOmega";

    internal static readonly LocalisedString
        CrestName = new($"Mods.{Id}", "CREST_NAME"),
        CrestDesc = new($"Mods.{Id}", "CREST_DESC");

    private void Awake() {
        Log = Logger;
        Logger.LogInfo($"Plugin {Name} ({Id}) has loaded!");

        #region Crest init + sprites
        // The art is centred, so the pivot is the middle and no slot offset is needed.
        Vector2 pivot = new(0.5f, 0.5f);

        Sprite
            linework   = LoadEmbeddedPngAsSprite("Crest.png", pivot),
            silhouette = LoadEmbeddedPngAsSprite("CrestSilhouette.png", pivot),
            glow       = LoadEmbeddedPngAsSprite("CrestGlow.png", pivot);

        Crest = NeedleforgePlugin.AddCrest(CrestId, CrestName, CrestDesc, linework, silhouette, glow);
        #endregion

        #region Tool slots: 2 red, 2 yellow, 3 blue, 1 skill
        // Attack-type slots (red + skill) each get their own direction binding.
        Crest.AddSkillSlot(AttackToolBinding.Down,    new( 0.00f,  2.10f), false);

        Crest.AddRedSlot(AttackToolBinding.Neutral,   new( 2.10f,  0.90f), false);
        Crest.AddRedSlot(AttackToolBinding.Up,        new(-2.10f,  0.90f), false);

        Crest.AddYellowSlot(new( 2.10f, -0.75f), false);
        Crest.AddYellowSlot(new(-2.10f, -0.75f), false);

        Crest.AddBlueSlot(new(-1.40f, -2.20f), false);
        Crest.AddBlueSlot(new( 1.40f, -2.20f), false);
        Crest.AddBlueSlot(new( 0.00f, -3.10f), false);

        Crest.ApplyAutoSlotNavigation(slotDimensions: new(1.25f, 0.75f));
        #endregion

        #region Gameplay
        // HUD frame uses a vanilla preset for now.
        Crest.HudFrame.Preset = VanillaCrest.HUNTER_V3;

        // Heal: no BindEvent / BindCompleteEvent is set on purpose, so the crest
        // uses the standard bind -- the same as the Wanderer Crest, which has no special bind.

        // Witch attacks + Wanderer speed (see Moveset.cs).
        Crest.Moveset.OnInitialized += Moveset.Setup;
        #endregion
    }
}

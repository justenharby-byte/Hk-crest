using Needleforge.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;
using static AlphaOmegaCrest.AlphaOmegaCrestPlugin;
using ConfigGroup = HeroController.ConfigGroup;

namespace AlphaOmegaCrest;

/// <summary>
/// Witch attacks (all slashes except charged) + Wanderer charged slash + Wanderer timing/speed.
/// Needleforge pre-fills a crest with Hunter's moveset; we overwrite it here.
/// Everything is copied by reflection so we don't depend on exact field names.
/// </summary>
internal static class Moveset {

    private const BindingFlags All =
        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    private static GameObject? animLibObj;

    internal static void Setup() {
        try {
            HeroController hc = HeroController.instance;
            ConfigGroup
                myCg = Crest.Moveset.ConfigGroup!,
                witchCg = hc.configs.First(x => x.Config.name == "Whip");
            HeroConfigNeedleforge myConfig = Crest.Moveset.HeroConfig!;
            HeroControllerConfig witchConfig = ToolItemManager.GetCrestByName("Witch").HeroConfig;

            // 1) Wanderer feel: copy every config value (timings, anim overrides) from Wanderer.
            tk2dSpriteAnimation? wandererLib = null;
            HeroControllerConfig? wandererConfig = null;
            try {
                wandererConfig = ToolItemManager.GetCrestByName("Wanderer").HeroConfig;
            }
            catch (Exception e) {
                Log.LogWarning($"Wanderer crest not found, keeping Hunter timings: {e.Message}");
            }
            if (wandererConfig != null) {
                CopyFields(typeof(HeroControllerConfig), wandererConfig, myConfig);
                wandererLib = wandererConfig.heroAnimOverrideLib;
            }

            // 2) Hornet animations: Wanderer's full set (includes its charged clips).
            //    Charged-slash config values were already copied from Wanderer in step 1.
            if (wandererLib != null)
                myConfig.heroAnimOverrideLib = wandererLib;

            // 3) Attack objects: Witch for everything except charged, Wanderer for charged.
            CloneAttackObjects(witchCg, myCg, name => !IsCharge(name));
            if (wandererConfig != null) {
                ConfigGroup wandererCg = hc.configs.First(x => x.Config == wandererConfig);
                CloneAttackObjects(wandererCg, myCg, IsCharge);
            }
            else {
                CloneAttackObjects(witchCg, myCg, IsCharge);
                myConfig.SetChargedSlashFields(
                    chain: witchConfig.chargeSlashChain,
                    lungeSpeed: witchConfig.chargeSlashLungeSpeed,
                    lungeDeceleration: witchConfig.chargeSlashLungeDeceleration,
                    recoils: witchConfig.chargeSlashRecoils
                );
                myConfig.heroAnimOverrideLib = BuildAnimationLibrary(null, witchConfig.heroAnimOverrideLib);
            }

            Log.LogInfo("Alpha & Omega moveset set up (Witch attacks, Wanderer charge + speed).");
        }
        catch (Exception e) {
            Log.LogError($"Moveset setup failed, crest will fall back to Hunter attacks: {e}");
        }
    }

    private static void CopyFields(Type type, object from, object to) {
        foreach (FieldInfo f in type.GetFields(All).Where(f => !f.IsStatic && !f.IsInitOnly))
            f.SetValue(to, f.GetValue(from));
    }

    /// <summary>Clones every GameObject (and remaps component) attack reference from Witch.</summary>
    private static bool IsCharge(string name) => name.IndexOf("Charge", StringComparison.OrdinalIgnoreCase) >= 0;

    private static void CloneAttackObjects(ConfigGroup src, ConfigGroup dst, Func<string, bool> include) {
        Transform parent = dst.ActiveRoot.transform;
        Dictionary<GameObject, GameObject> map = new();

        // GameObject members (slashes, alt slashes, up/down, wall, charge, ...)
        foreach (MemberRef m in Members(typeof(ConfigGroup)).Where(m => m.Type == typeof(GameObject))) {
            if (m.Name == "ActiveRoot" || !include(m.Name)) continue;
            GameObject? orig = m.Get(src) as GameObject;
            if (!orig) continue;
            if (!map.TryGetValue(orig!, out GameObject clone)) {
                clone = UnityEngine.Object.Instantiate(orig!, parent);
                map[orig!] = clone;
            }
            m.Set(dst, clone);
        }

        // Component members (e.g. NailSlash refs) must point into the clones, not the Witch originals.
        foreach (MemberRef m in Members(typeof(ConfigGroup)).Where(m => typeof(Component).IsAssignableFrom(m.Type) && include(m.Name))) {
            Component? orig = m.Get(src) as Component;
            if (!orig) continue;
            Component? remapped = Remap(orig!, map);
            if (remapped) m.Set(dst, remapped);
        }
    }

    private static Component? Remap(Component orig, Dictionary<GameObject, GameObject> map) {
        List<int> path = new();
        Transform? t = orig.transform;
        while (t != null) {
            if (map.TryGetValue(t.gameObject, out GameObject clone)) {
                Transform c = clone.transform;
                for (int i = path.Count - 1; i >= 0; i--) {
                    if (path[i] >= c.childCount) return null;
                    c = c.GetChild(path[i]);
                }
                return c.GetComponent(orig.GetType());
            }
            if (t.parent == null) break;
            path.Add(t.GetSiblingIndex());
            t = t.parent;
        }
        return null;
    }

    /// <summary>Wanderer's clips for Hornet, plus Witch's charged-slash clips.</summary>
    private static tk2dSpriteAnimation BuildAnimationLibrary(tk2dSpriteAnimation? baseLib, tk2dSpriteAnimation witchLib) {
        if (animLibObj)
            return animLibObj!.GetComponent<tk2dSpriteAnimation>();

        animLibObj = new GameObject($"{CrestId}_AnimLib") { hideFlags = HideFlags.HideAndDontSave };
        UnityEngine.Object.DontDestroyOnLoad(animLibObj);
        var lib = animLibObj.AddComponent<tk2dSpriteAnimation>();

        var clips = new List<tk2dSpriteAnimationClip>();
        if (baseLib != null)
            clips.AddRange(baseLib.clips.Where(c => !c.name.Contains("Charged")));
        clips.AddRange(witchLib.clips.Where(c => c.name.Contains("Charged")));

        lib.clips = clips.ToArray();
        lib.isValid = false;
        lib.ValidateLookup();
        return lib;
    }

    // ---- small field/property abstraction ----
    private readonly struct MemberRef {
        private readonly FieldInfo? field;
        private readonly PropertyInfo? prop;
        internal MemberRef(FieldInfo f) { field = f; prop = null; }
        internal MemberRef(PropertyInfo p) { prop = p; field = null; }
        internal string Name => field?.Name ?? prop!.Name;
        internal Type Type => field?.FieldType ?? prop!.PropertyType;
        internal object? Get(object o) => field != null ? field.GetValue(o) : prop!.GetValue(o);
        internal void Set(object o, object? v) {
            if (field != null) field.SetValue(o, v); else prop!.SetValue(o, v);
        }
    }

    private static IEnumerable<MemberRef> Members(Type t) {
        foreach (FieldInfo f in t.GetFields(All).Where(f => !f.IsStatic && !f.IsInitOnly))
            yield return new MemberRef(f);
        foreach (PropertyInfo p in t.GetProperties(All).Where(p => p.CanRead && p.CanWrite && p.GetIndexParameters().Length == 0))
            yield return new MemberRef(p);
    }
}

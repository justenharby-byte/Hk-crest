# The Alpha and the Omega Crest (Hollow Knight: Silksong)

Slots: 2 red, 2 yellow, 3 blue, 1 skill. Heal: standard bind (as Wanderer).
Moveset: Witch attacks + Wanderer speed (Moveset.cs, reflection-based, untested in-game).

## Build
1. Install .NET SDK 8+.
2. (Optional) create SilksongPath.props next to the .csproj:
   <Project><PropertyGroup>
     <SilksongPluginsFolder>C:\...\Hollow Knight Silksong\BepInEx\plugins</SilksongPluginsFolder>
   </PropertyGroup></Project>
3. dotnet build -c Release

## Install (manual)
BepInEx/plugins/AlphaOmegaCrest/AlphaOmegaCrest.dll
BepInEx/plugins/AlphaOmegaCrest/Languages/EN.json
Needs: BepInExPack Silksong, Needleforge 0.9.0+, I18N 1.1.1+.

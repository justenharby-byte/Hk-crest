using System;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace AlphaOmegaCrest.Utils;

internal static class ResourceUtils {

    private static readonly Assembly Asm = typeof(ResourceUtils).Assembly;

    /// <summary>Loads an embedded PNG (matched by file name suffix) as a Sprite.</summary>
    internal static Sprite LoadEmbeddedPngAsSprite(string fileName, Vector2 pivot, float pixelsPerUnit = 100f) {
        string? resName = Asm.GetManifestResourceNames()
            .FirstOrDefault(n => n.EndsWith(fileName, StringComparison.OrdinalIgnoreCase));
        if (resName == null)
            throw new FileNotFoundException($"Embedded resource not found: {fileName}");

        using Stream stream = Asm.GetManifestResourceStream(resName)!;
        using MemoryStream ms = new();
        stream.CopyTo(ms);

        Texture2D tex = new(2, 2, TextureFormat.RGBA32, false) {
            filterMode = FilterMode.Bilinear,
            wrapMode = TextureWrapMode.Clamp,
            hideFlags = HideFlags.HideAndDontSave,
        };
        if (!ImageConversion.LoadImage(tex, ms.ToArray()))
            throw new InvalidDataException($"Could not decode PNG: {fileName}");

        Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), pivot, pixelsPerUnit);
        sprite.hideFlags = HideFlags.HideAndDontSave;
        return sprite;
    }
}
